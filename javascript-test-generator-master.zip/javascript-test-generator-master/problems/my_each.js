Array.prototype.myEach = function (func) {

}
