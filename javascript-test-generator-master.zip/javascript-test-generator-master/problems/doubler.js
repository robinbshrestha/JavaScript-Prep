// Write a method that doubles each element in an array

function doubler(array) {

}
