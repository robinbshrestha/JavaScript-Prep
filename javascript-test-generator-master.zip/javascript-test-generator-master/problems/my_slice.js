// write String.prototype.mySlice. It should take a start index and an
// (optional) end index.

String.prototype.mySlice = function () {

}
