Array.prototype.myReverse = function () {

}
