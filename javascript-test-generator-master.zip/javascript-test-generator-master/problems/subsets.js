// returns all subsets of an array

function subsets(array) {

}
