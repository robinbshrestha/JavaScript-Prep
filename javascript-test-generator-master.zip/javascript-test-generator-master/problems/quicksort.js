// Write a monkey patch of quick sort that accepts a callback

Array.prototype.quickSort = function (func) {

}
