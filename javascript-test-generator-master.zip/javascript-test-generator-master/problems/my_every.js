Array.prototype.myEvery = function (func) {

}
