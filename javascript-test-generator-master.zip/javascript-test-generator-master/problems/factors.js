// Write a method that returns the factors of a number in ascending order.

function factors(num) {
  
}
