// write Function.prototype.myBind.
Function.prototype.myBind = function () {
  
}
