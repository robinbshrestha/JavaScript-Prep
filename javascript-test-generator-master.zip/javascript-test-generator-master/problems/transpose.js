function transpose(arr) {

};
