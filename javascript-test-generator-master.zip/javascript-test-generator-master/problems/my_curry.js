Function.prototype.myCurry = function (numArgs) {

};
